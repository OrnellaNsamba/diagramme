/**
 * Spring Data JPA repositories.
 */
package com.stroustrup.gestioncongerabsence.repository;
