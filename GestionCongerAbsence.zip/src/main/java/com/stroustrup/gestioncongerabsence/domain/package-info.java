/**
 * JPA domain objects.
 */
package com.stroustrup.gestioncongerabsence.domain;
