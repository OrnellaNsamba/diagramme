/**
 * Spring MVC REST controllers.
 */
package com.stroustrup.gestioncongerabsence.web.rest;
