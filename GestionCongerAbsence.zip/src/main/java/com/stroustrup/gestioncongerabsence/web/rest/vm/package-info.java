/**
 * View Models used by Spring MVC REST controllers.
 */
package com.stroustrup.gestioncongerabsence.web.rest.vm;
