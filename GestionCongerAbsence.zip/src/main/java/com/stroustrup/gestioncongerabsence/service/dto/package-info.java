/**
 * Data Transfer Objects.
 */
package com.stroustrup.gestioncongerabsence.service.dto;
