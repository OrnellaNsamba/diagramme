/**
 * Service layer beans.
 */
package com.stroustrup.gestioncongerabsence.service;
