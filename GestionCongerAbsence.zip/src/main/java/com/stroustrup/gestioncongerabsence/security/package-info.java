/**
 * Spring Security configuration.
 */
package com.stroustrup.gestioncongerabsence.security;
